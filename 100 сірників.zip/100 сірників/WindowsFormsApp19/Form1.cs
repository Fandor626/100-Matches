﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp19
{
    public partial class StartMenu : Form
    {
        public StartMenu()
        {
            InitializeComponent();

        }

        private void ExitButton_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void InfoButton_Click(object sender, EventArgs e)
        {
            Info Info = new Info();
            Info.ShowDialog();
        }

        private void StartButton_Click(object sender, EventArgs e)
        {
            Game game = new Game();
            game.Show();
            Hide();        
        }
    }
}
