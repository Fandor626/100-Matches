﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp19
{
    public partial class Game : Form
    {
        public Game()
        {
            InitializeComponent();
        }
        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }
        private void button1_Click(object sender, EventArgs e)
        {
            Button but = (Button)sender;
            int count = Convert.ToInt32(but.Text);
            int balance = Convert.ToInt32(label1.Text);
            if (balance <= 0)
            {
                return;
            }
            balance -= count;
            string match = " match";
            if (count > 1)
            {
                 match = " matches";
            }
            listBox1.Items.Add("Player tooks " + count.ToString() + match + " there are only " + balance + " matches");
            if (balance <= 0)
            {
                label1.Text = "0";
                listBox1.Items.Add("Computer win ");              
                return;
            }
            if (balance > 20)
            {
                Random rand = new Random();
                count = rand.Next(10) + 1;
            }
            else
                if (balance < 10)
            {
                count = balance;
            }
            match = "match";
            if (count > 1 && balance > 1||balance<=0)
            {
                match = " matches";
            }
            balance -= count;  
            label1.Text = balance.ToString();
            listBox1.Items.Add("Computer tooks " + count.ToString() + match + " there are only " + balance + " matches");
            if (balance <= 0)
            {            
                 label1.Text = "0";
                 listBox1.Items.Add("Player win ");                  
                 return;
            }
        }
        private void ExitGame_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        private void ExitMenu_Click(object sender, EventArgs e)
        {
            StartMenu startMenu = new StartMenu();
            startMenu.Show();
            Application.Exit();
        }
        private void NewGame_Click(object sender, EventArgs e)
        {
            label1.Text = "100";
            listBox1.Items.Clear();
        }
    }
}
